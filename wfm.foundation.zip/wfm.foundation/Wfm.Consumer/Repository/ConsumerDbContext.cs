﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Wfm.Foundation.Core.Entities;
using Wfm.Foundation.Core.Repository;

namespace Wfm.Consumer
{
    public class ConsumerDbContext : WfmDbContext
    {
        public ConsumerDbContext(DbContextOptions<ConsumerDbContext> options) : base(options)
        {
            
        }
        public DbSet<Book> Books { get; set; }
    }
}
