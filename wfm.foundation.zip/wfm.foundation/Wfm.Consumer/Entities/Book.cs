﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Wfm.Foundation.Core.Entities;

namespace Wfm.Consumer
{
    public class Book: BaseEntity
    {
        public string Name { get; set; }
    }
}
