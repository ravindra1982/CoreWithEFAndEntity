﻿using Wfm.Consumer.Services.Interface;
using Wfm.Foundation.Core.Services.Implementation;

namespace Wfm.Consumer.Services.Implementation
{
    public class BookSvc: BaseSvc<Book>, IBookSvc
    {
        public BookSvc(ConsumerDbContext dbContext):base(dbContext)
        {

        }
    }
}
