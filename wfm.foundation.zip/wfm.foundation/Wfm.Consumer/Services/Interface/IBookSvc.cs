﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Wfm.Foundation.Core.Services.Interface;

namespace Wfm.Consumer.Services.Interface
{
    public interface IBookSvc : IBaseSvc<Book>
    {
    }
}
