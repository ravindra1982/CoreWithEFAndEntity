﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Wfm.Consumer.Models;
using Wfm.Consumer.Services.Interface;
using Wfm.Foundation.Logger;

namespace Wfm.Consumer.Controllers
{
    public class HomeController : Controller
    {
        private readonly WfmLogger<HomeController> _wfmLogger;
        private readonly IBookSvc _booksService;
        public HomeController(IBookSvc bookSvc, ILoggerFactory lgFactory)
        {
            _booksService = bookSvc;
            _wfmLogger = new WfmLogger<HomeController>(lgFactory);
        }

        public IActionResult Index()
        {
            _wfmLogger.LogDebug("Started getting books detals");
            Book obj = new Book();
            obj.CreatedBy=3;
            obj.CreatedDate= DateTime.Now;
            obj.ModifiedDate = DateTime.Now;
            obj.Name = "Test" + obj.CreatedDate;

            _booksService.Insert(obj);

            var result = _booksService.GetAll();
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
