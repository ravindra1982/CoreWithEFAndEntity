﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Threading.Tasks;

namespace Wfm.Foundation.Core.Data
{
    public class Repository<TEntity> : IRepository<TEntity> where TEntity : class
    {
        private DbContext dBContext;

        public Repository(DbContext _dbContext)
        {
            this.dBContext = _dbContext;
        }

        private DbSet<TEntity> Entities;
        public async Task<TEntity> Create(TEntity entity)
        {
            if (entity == null)
            {
                throw new ArgumentNullException(nameof(entity));
            }
            await dBContext.Set<TEntity>().AddAsync(entity);
            await dBContext.SaveChangesAsync();
            return entity;
        }

        public async void Create(List<TEntity> entities)
        {
            if (entities == null || entities.Count == 0)
            {
                throw new ArgumentNullException(nameof(entities));
            }
            await dBContext.Set<TEntity>().AddRangeAsync(entities);
        }

        public void Delete(TEntity entity)
        {
            if (entity == null)
            {
                throw new ArgumentNullException(nameof(entity));
            }
            dBContext.Set<TEntity>().Remove(entity);
            dBContext.SaveChangesAsync();
        }

        public void Delete(List<TEntity> entities)
        {
            if (entities == null || entities.Count == 0)
            {
                throw new ArgumentNullException(nameof(entities));
            }
            dBContext.Set<TEntity>().RemoveRange(entities);
            dBContext.SaveChangesAsync();
        }

        public async Task<IEnumerable<TEntity>> GetAll()
        {
            return await dBContext.Set<TEntity>().ToListAsync();
        }

        public async Task<TEntity> GetById(object id)
        {
            return await dBContext.Set<TEntity>().FindAsync(id);
        }

        public void Update(TEntity entity)
        {
            if (entity == null)
            {
                throw new ArgumentNullException(nameof(entity));
            }
            dBContext.Set<TEntity>().Update(entity);
            dBContext.SaveChangesAsync();
        }

        public void Update(List<TEntity> entities)
        {
            if (entities == null || entities.Count == 0)
            {
                throw new ArgumentNullException(nameof(entities));
            }
            dBContext.Set<TEntity>().UpdateRange(entities);
            dBContext.SaveChangesAsync();
        }
    }
}
