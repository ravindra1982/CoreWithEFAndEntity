﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Reflection.Emit;
using System.Threading.Tasks;

namespace Wfm.Foundation.Core.Repository
{
    public class WfmDbContext : DbContext
    {
        public WfmDbContext(DbContextOptions<WfmDbContext> options) : base(options) { }

        /// <summary>
        /// This allows a sub class to call the base class 'DbContext' non typed constructor
        /// This is need because instances of the subclasses will use a specifc typed DbContextOptions
        /// which can not be converted into the paramter in the above constructor
        /// </summary>
        /// <param name="options"></param>
        protected WfmDbContext(DbContextOptions options) : base(options) { }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            var typesToRegister = Assembly.GetExecutingAssembly().GetTypes()
                                         .Where(type => !String.IsNullOrEmpty(type.Namespace))
                                         .Where(type => type.BaseType != null
                                                         && type.BaseType.IsGenericType
                                                         && type.BaseType.GetGenericTypeDefinition() == typeof(IEntityTypeConfiguration<>));
            foreach (var type in typesToRegister)
            {
                dynamic configurationInstance = Activator.CreateInstance(type);
                modelBuilder.ApplyConfiguration(configurationInstance);
            }
            base.OnModelCreating(modelBuilder);
        }
    }

    //public class WfmDBContextSQLServer : WfmDbContext
    //{

    //    public WfmDBContextSQLServer(DbContextOptions<WfmDBContextSQLServer> options) : base(options)
    //    {

    //    }

    //    protected override void OnModelCreating(ModelBuilder modelBuilder)
    //    {
    //        var typesToRegister = Assembly.GetExecutingAssembly().GetTypes()
    //                                    .Where(type => !String.IsNullOrEmpty(type.Namespace))
    //                                    .Where(type => type.BaseType != null
    //                                                    && type.BaseType.IsGenericType
    //                                                    && type.BaseType.GetGenericTypeDefinition() == typeof(IEntityTypeConfiguration<>));
    //        foreach(var type in typesToRegister)
    //        {
    //            dynamic configurationInstance = Activator.CreateInstance(type);
    //            modelBuilder.ApplyConfiguration(configurationInstance);
    //        }
    //        base.OnModelCreating(modelBuilder);
    //    }
    //}
}
