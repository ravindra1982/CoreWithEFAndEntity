﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Wfm.Foundation.Core.Data
{
    public interface IRepository<TEntity> where TEntity: class
    {
        Task<IEnumerable<TEntity>> GetAll();
        Task<TEntity> GetById(object id);
        Task<TEntity> Create(TEntity entity);
        void Update(TEntity entity);
        void Delete(TEntity entity);
        void Create(List<TEntity> entities);
        void Update(List<TEntity> entities);
        void Delete(List<TEntity> entities);
    }
}
