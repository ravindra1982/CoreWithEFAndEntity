﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Wfm.Foundation.Core.Services.Interface
{
    public interface IBaseSvc<TEntity>
    {
        List<TEntity> GetAll();
        TEntity GetById(int id);
        TEntity Insert(TEntity entity);
        void Update(TEntity entity);
        void Delete(TEntity entity);
        void Insert(List<TEntity> entities);
        void Update(List<TEntity> entities);
        void Delete(List<TEntity> entities);
    }
}
