﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Wfm.Foundation.Core.Data;
using Wfm.Foundation.Core.Services.Interface;

namespace Wfm.Foundation.Core.Services.Implementation
{
    public class BaseSvc<TEntity> : IBaseSvc<TEntity> where TEntity : class
    {
        IRepository<TEntity> _repository;
        DbContext _dbContext;

        public BaseSvc(DbContext dbContext)
        {
            _dbContext = dbContext;
            _repository = new Repository<TEntity>(_dbContext);
        }
        public void Delete(TEntity entity)
        {
            _repository.Delete(entity);
        }

        public void Delete(List<TEntity> entities)
        {
            _repository.Delete(entities);
        }

        public List<TEntity> GetAll()
        {
           return _repository.GetAll().Result.ToList();
        }

        public TEntity GetById(int id)
        {
            return _repository.GetById(id).Result;
        }

        public TEntity Insert(TEntity entity)
        {
            return _repository.Create(entity).Result;
        }

        public void Insert(List<TEntity> entities)
        {
            _repository.Create(entities);
        }

        public void Update(TEntity entity)
        {
            _repository.Update(entity);
        }

        public void Update(List<TEntity> entities)
        {
            _repository.Update(entities);
        }
    }
}
