﻿using Microsoft.Extensions.Logging;
using System;

namespace Wfm.Foundation.Logger
{
    public class WfmLogger<T> : Logger<T> where T : class
    {
        public WfmLogger(ILoggerFactory lgFactory) : base(lgFactory) { }

        public void LogEvents(string message)
        {
            //Place holders for NPI logging
        }
    }
}
