﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Routing;
using Microsoft.Extensions.Logging;
using Wfm.Foundation.Core.Entities;
using Wfm.Foundation.Core.Services.Interface;
using Wfm.Foundation.Logger;

namespace Wfm.Foundation.Core.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class WeatherForecastController : ControllerBase
    {
        private static readonly string[] Summaries = new[]
        {
            "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
        };

        //private readonly WfmLogger<WeatherForecastController> _wfmLogger;
        //private readonly IBookSvc _booksService;
        //public WeatherForecastController(IBookSvc bookSvc, WfmLogger<WeatherForecastController> wfmLogger)
        //{
        //    _logger = logger;
        //    _booksService = bookSvc;
        //    _wfmLogger = wfmLogger;
        //}

        [HttpGet]
        public IEnumerable<WeatherForecast> Get()
        {
            var rng = new Random();
            return Enumerable.Range(1, 5).Select(index => new WeatherForecast
            {
                Date = DateTime.Now.AddDays(index),
                TemperatureC = rng.Next(-20, 55),
                Summary = Summaries[rng.Next(Summaries.Length)]
            })
            .ToArray();
        }

        //[HttpGet]
        //[Route("[controller]/GetBooks")]
        //public List<Book> GetBooks()
        //{
        //    _wfmLogger.LogDebug("Started getting books detals");
        //    return _booksService.GetAll();
        //}
    }
}
